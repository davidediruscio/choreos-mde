package it.univaq.di.choreos.stockorder.client;


public class TestWS {

	
	public static void main(String[] args) {
		System.out.println("ciao");
		StockOrderService service = new StockOrderService();
		service.getStockOrderPort().stockOrder("GOOG", 10.0F, 10);
	}

}
