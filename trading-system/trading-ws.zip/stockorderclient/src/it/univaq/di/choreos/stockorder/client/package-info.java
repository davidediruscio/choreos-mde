@javax.xml.bind.annotation.XmlSchema(namespace = "http://choreos.di.univaq.it")
package it.univaq.di.choreos.stockorder.client;
