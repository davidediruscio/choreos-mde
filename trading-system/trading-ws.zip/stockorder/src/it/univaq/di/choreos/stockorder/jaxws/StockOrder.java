
package it.univaq.di.choreos.stockorder.jaxws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "stockOrder", namespace = "http://choreos.di.univaq.it")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "stockOrder", namespace = "http://choreos.di.univaq.it", propOrder = {
    "stockSymbol",
    "maxPrice",
    "quantity"
})
public class StockOrder {

    @XmlElement(name = "stockSymbol", namespace = "")
    private String stockSymbol;
    @XmlElement(name = "maxPrice", namespace = "")
    private float maxPrice;
    @XmlElement(name = "quantity", namespace = "")
    private int quantity;

    /**
     * 
     * @return
     *     returns String
     */
    public String getStockSymbol() {
        return this.stockSymbol;
    }

    /**
     * 
     * @param stockSymbol
     *     the value for the stockSymbol property
     */
    public void setStockSymbol(String stockSymbol) {
        this.stockSymbol = stockSymbol;
    }

    /**
     * 
     * @return
     *     returns float
     */
    public float getMaxPrice() {
        return this.maxPrice;
    }

    /**
     * 
     * @param maxPrice
     *     the value for the maxPrice property
     */
    public void setMaxPrice(float maxPrice) {
        this.maxPrice = maxPrice;
    }

    /**
     * 
     * @return
     *     returns int
     */
    public int getQuantity() {
        return this.quantity;
    }

    /**
     * 
     * @param quantity
     *     the value for the quantity property
     */
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

}
