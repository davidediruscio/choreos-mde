
package it.univaq.di.choreos.stockconfirm.jaxws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "orderconfirm", namespace = "http://choreos.di.univaq.it")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "orderconfirm", namespace = "http://choreos.di.univaq.it", propOrder = {
    "orderNumber",
    "quantity"
})
public class Orderconfirm {

    @XmlElement(name = "orderNumber", namespace = "")
    private String orderNumber;
    @XmlElement(name = "quantity", namespace = "")
    private int quantity;

    /**
     * 
     * @return
     *     returns String
     */
    public String getOrderNumber() {
        return this.orderNumber;
    }

    /**
     * 
     * @param orderNumber
     *     the value for the orderNumber property
     */
    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    /**
     * 
     * @return
     *     returns int
     */
    public int getQuantity() {
        return this.quantity;
    }

    /**
     * 
     * @param quantity
     *     the value for the quantity property
     */
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

}
