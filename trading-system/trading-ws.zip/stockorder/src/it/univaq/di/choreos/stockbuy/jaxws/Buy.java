
package it.univaq.di.choreos.stockbuy.jaxws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "buy", namespace = "http://choreos.di.univaq.it")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "buy", namespace = "http://choreos.di.univaq.it", propOrder = {
    "stockSymbol",
    "quantity"
})
public class Buy {

    @XmlElement(name = "stockSymbol", namespace = "")
    private String stockSymbol;
    @XmlElement(name = "quantity", namespace = "")
    private int quantity;

    /**
     * 
     * @return
     *     returns String
     */
    public String getStockSymbol() {
        return this.stockSymbol;
    }

    /**
     * 
     * @param stockSymbol
     *     the value for the stockSymbol property
     */
    public void setStockSymbol(String stockSymbol) {
        this.stockSymbol = stockSymbol;
    }

    /**
     * 
     * @return
     *     returns int
     */
    public int getQuantity() {
        return this.quantity;
    }

    /**
     * 
     * @param quantity
     *     the value for the quantity property
     */
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

}
