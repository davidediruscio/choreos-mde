package it.univaq.di.choreos.stockorder;

import it.univaq.di.choreos.stockbuy.client.StockBuy;
import it.univaq.di.choreos.stockbuy.client.StockBuy_Service;

import javax.jws.Oneway;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

@WebService( serviceName="", targetNamespace="http://choreos.di.univaq.it", portName="StockOrderPort" )
public class StockOrder {

	
	@WebMethod( operationName="stockOrder" )
	@Oneway
	public void stockOrder( @WebParam( name="stockSymbol" ) String stockSymbol, @WebParam( name="maxPrice" ) float maxPrice, @WebParam( name="quantity" ) int quantity ) {
		System.out.println("StockOrder->stockOrder");

		StockBuy_Service service = new StockBuy_Service();
		StockBuy stockBuy = service.getStockBuyPort();
		stockBuy.buy("", 10);
		//Invocare il WS esterno che ritorna la quotazione
		//Se la quotazione e' inferiore a maxPrice chiamare il servizio di StockBuy
		
	}
}
