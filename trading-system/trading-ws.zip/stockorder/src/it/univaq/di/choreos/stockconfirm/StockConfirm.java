package it.univaq.di.choreos.stockconfirm;

import javax.jws.Oneway;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

@WebService( serviceName="StockConfirm", targetNamespace="http://choreos.di.univaq.it", portName="StockConfirmPort" )
public class StockConfirm {

	@WebMethod( operationName="orderconfirm" )
	@Oneway
	public void orderconfirm( @WebParam( name="orderNumber" ) String orderNumber, @WebParam( name="quantity" ) int quantity ) {
		//Effettua l'acquisto per tutti e tre i WS di trading
		System.out.println("StockConfirm->orderconfirm");
	}
}
