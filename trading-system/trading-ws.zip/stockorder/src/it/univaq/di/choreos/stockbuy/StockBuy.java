package it.univaq.di.choreos.stockbuy;

import it.fineco.trading.client.Stocktrade2;
import it.fineco.trading.client.Stocktrade2_Service;
import it.iwbank.trading.client.Stocktrade3;
import it.iwbank.trading.client.Stocktrade3_Service;

import javax.jws.Oneway;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

import com.ubs.trading.client.Stocktrade1;
import com.ubs.trading.client.Stocktrade1_Service;

@WebService( serviceName="StockBuy", targetNamespace="http://choreos.di.univaq.it", portName="StockBuyPort" )
public class StockBuy {

	
	@WebMethod( operationName="buy" )
	@Oneway
	public void buy( @WebParam( name="stockSymbol" ) String stockSymbol, @WebParam( name="quantity" ) int quantity ) {
		//Effettua l'acquisto per tutti e tre i WS di trading
		//Forse si puo' mettere un id generato per identificare l'ordine che poi verra' ritornato indietro
		System.out.println("StockBuy->buy");
		//Invio a FOREX
		System.out.println("StockBuy->buy-> prima di forex");
		Stocktrade1_Service stockTradeService = new Stocktrade1_Service();
		Stocktrade1 stockTradePort = stockTradeService.getStocktrade1Port();
		stockTradePort.buy1("1", stockSymbol, quantity);
		System.out.println("StockBuy->buy-> dopo di forex");
		//Invio a FINECO
		System.out.println("StockBuy->buy-> prima di fineco");
		Stocktrade2_Service titoliAzionariService = new Stocktrade2_Service();
		Stocktrade2 titoliAzionariPort = titoliAzionariService.getStocktrade2Port();
		titoliAzionariPort.buy2("1", stockSymbol, quantity);
		System.out.println("StockBuy->buy-> dopo di fineco");
		//Invia a IWBANK
		System.out.println("StockBuy->buy-> prima di iwbank");
		Stocktrade3_Service acquistoAzioniService = new Stocktrade3_Service();
		Stocktrade3 acquistoAzioniPort = acquistoAzioniService.getStocktrade3Port();
		acquistoAzioniPort.buy3("1", stockSymbol, quantity);
		System.out.println("StockBuy->buy-> dopo di iwbank");
	}
}
