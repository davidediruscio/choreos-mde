
package it.iwbank.trading.client;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the it.iwbank.trading.client package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _Buy3_QNAME = new QName("http://trading.iwbank.it", "buy3");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: it.iwbank.trading.client
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link Buy3 }
     * 
     */
    public Buy3 createBuy3() {
        return new Buy3();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Buy3 }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://trading.iwbank.it", name = "buy3")
    public JAXBElement<Buy3> createBuy3(Buy3 value) {
        return new JAXBElement<Buy3>(_Buy3_QNAME, Buy3 .class, null, value);
    }

}
