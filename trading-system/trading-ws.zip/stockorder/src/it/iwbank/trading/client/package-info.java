@javax.xml.bind.annotation.XmlSchema(namespace = "http://trading.iwbank.it")
package it.iwbank.trading.client;
