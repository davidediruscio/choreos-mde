@javax.xml.bind.annotation.XmlSchema(namespace = "http://trading.fineco.it")
package it.fineco.trading.client;
