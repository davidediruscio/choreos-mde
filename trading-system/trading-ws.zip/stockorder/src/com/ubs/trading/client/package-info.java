@javax.xml.bind.annotation.XmlSchema(namespace = "http://trading.ubs.com")
package com.ubs.trading.client;
