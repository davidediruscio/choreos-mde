@javax.xml.bind.annotation.XmlSchema(namespace = "http://choreos.di.univaq.it")
package it.univaq.di.choreos.coordinationprotocol.channel.client;
