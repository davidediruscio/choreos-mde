package it.univaq.di.choreos.coordinationprotocol.channel;

import it.univaq.di.choreos.coordinationprotocol.channel.client.WSCoordinationChannel;
import it.univaq.di.choreos.coordinationprotocol.channel.client.WSCoordinationChannel_Service;

import java.net.MalformedURLException;
import java.net.URL;

import javax.xml.namespace.QName;

public class Utility {
	private final static URL FINECO_WSDL_LOCATION;
    static {
        URL url = null;
        try {
            URL baseUrl;
            baseUrl = it.univaq.di.choreos.coordinationprotocol.channel.client.WSCoordinationChannel_Service.class.getResource(".");
            url = new URL(baseUrl, "http://localhost:10080/fineco-cd/wscoordinationchannel?wsdl");
        } catch (MalformedURLException e) {
        	e.printStackTrace();
        }
        FINECO_WSDL_LOCATION = url;
    }
    
	private final static URL UBS_WSDL_LOCATION;
    static {
        URL url = null;
        try {
            URL baseUrl;
            baseUrl = it.univaq.di.choreos.coordinationprotocol.channel.client.WSCoordinationChannel_Service.class.getResource(".");
            url = new URL(baseUrl, "http://localhost:11080/ubs-cd/wscoordinationchannel?wsdl");
        } catch (MalformedURLException e) {
        	e.printStackTrace();
        }
        UBS_WSDL_LOCATION = url;
    }
    
    private final static URL IWBANK_WSDL_LOCATION;
    static {
        URL url = null;
        try {
            URL baseUrl;
            baseUrl = it.univaq.di.choreos.coordinationprotocol.channel.client.WSCoordinationChannel_Service.class.getResource(".");
            url = new URL(baseUrl, "http://localhost:12080/iwbank-cd/wscoordinationchannel?wsdl");
        } catch (MalformedURLException e) {
        	e.printStackTrace();
        }
        IWBANK_WSDL_LOCATION = url;
    }
    
	public static void sendBlock(String request, String coordinationDelegateFrom, String coordinationDelegateTo, int timestamp) {
		WSCoordinationChannel_Service coordinationChannelService = new WSCoordinationChannel_Service(getUrl(coordinationDelegateTo), new QName("http://choreos.di.univaq.it", "WSCoordinationChannel"));
		WSCoordinationChannel coordinationChannelPort = coordinationChannelService.getWSCoordinationChannelPort();
		coordinationChannelPort.block(request, coordinationDelegateFrom, timestamp);
	}
	
	public static void sendAck(String request, String coordinationDelegateFrom, String coordinationDelegateTo, int timestamp) {
		WSCoordinationChannel_Service coordinationChannelService = new WSCoordinationChannel_Service(getUrl(coordinationDelegateTo), new QName("http://choreos.di.univaq.it", "WSCoordinationChannel"));
		WSCoordinationChannel coordinationChannelPort = coordinationChannelService.getWSCoordinationChannelPort();
		coordinationChannelPort.ack(request, coordinationDelegateFrom, timestamp);
		
	}
	
	public static void sendUnBlock(String request, String coordinationDelegateFrom, String coordinationDelegateTo, int timestamp) {
		WSCoordinationChannel_Service coordinationChannelService = new WSCoordinationChannel_Service(getUrl(coordinationDelegateTo), new QName("http://choreos.di.univaq.it", "WSCoordinationChannel"));
		WSCoordinationChannel coordinationChannelPort = coordinationChannelService.getWSCoordinationChannelPort();
		coordinationChannelPort.unblock(request, coordinationDelegateFrom, timestamp);
	}
	
	private static URL getUrl(String coordinationDelegateFrom) {
		URL url = null;
		if ("ubs-cd".equals(coordinationDelegateFrom)) {
			url = UBS_WSDL_LOCATION;
		}
		if ("iwbank-cd".equals(coordinationDelegateFrom)) {
			url = IWBANK_WSDL_LOCATION;
		}
		if ("fineco-cd".equals(coordinationDelegateFrom)) {
			url = FINECO_WSDL_LOCATION;
		}
		return url;
	}
}
