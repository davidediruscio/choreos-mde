package it.univaq.di.choreos.coordinationprotocol.algorithm;

import java.util.List;

import it.univaq.di.choreos.coordinationprotocol.algorithm.model.ChoreographyState;
import it.univaq.di.choreos.coordinationprotocol.algorithm.model.CoordinationResult;
import it.univaq.di.choreos.coordinationprotocol.algorithm.model.CDQueue;
import it.univaq.di.choreos.coordinationprotocol.algorithm.model.CDQueueElement;
import it.univaq.di.choreos.coordinationprotocol.algorithm.model.CoordinationDelegate;
import it.univaq.di.choreos.coordinationprotocol.algorithm.model.CoordMM.Coord;

public class CoordinationDelegateFacade {
	
	public CoordinationResult handleRules(String request, CoordinationDelegate coordinationDelegateFrom, Coord coord, ChoreographyState globalState) {
		System.out.println("CoordinationDelegateFacade->handleRequest begin");
		CoordinationResult result = CoordinationResult.ALLOWED;
		while (result!=CoordinationResult.RETRY) {
			result = handleRulesInternal(request, coordinationDelegateFrom, coord, globalState);
		}
		System.out.println("CoordinationDelegateFacade->handleRequest end");
		return result;
	}
	
	private CoordinationResult handleRulesInternal(String request, CoordinationDelegate coordinationDelegateFrom, Coord coord, ChoreographyState globalState) {

		CoordinationDelegateManager manager = CoordinationDelegateFactory.getInstance().getCoordinationDelegateManager();
		TimeStampManager timeStampManager = CoordinationDelegateFactory.getInstance().getTimeStampManager();
		CoordinationResult requestAllowed = manager.isRequestAllowedFromS(request, coordinationDelegateFrom, coord);
		if (CoordinationResult.DISCARD == requestAllowed) {
			//Discard
			return CoordinationResult.DISCARD;
		}

		
		List<CoordinationDelegate> coordinationDelegates = manager.getAllCoordinationDelegate(request, coordinationDelegateFrom, coord);
		if (coordinationDelegates == null || coordinationDelegates.isEmpty()) {
			return CoordinationResult.DISCARD;
		}

		CDQueue cdQueue = manager.getCDQueue(request, coordinationDelegateFrom, coord );
		for (CoordinationDelegate coordinationDelegate : coordinationDelegates) {
			int timeStamp = timeStampManager.incrementTimeStamp();
			manager.sendBlock(request, coordinationDelegateFrom.getName(), coordinationDelegate.getName(), timeStamp, globalState);
			CDQueueElement cdQueueElement = new CDQueueElement(timeStamp, coordinationDelegate);
			cdQueue.addBlock(cdQueueElement);
		}

		cdQueue.waitAllAcks();
		
		if (manager.isPrivilegeGranted(request, coordinationDelegateFrom, coord, globalState))  {
			return CoordinationResult.FORWARD;
		} else {
			cdQueue.waitForAllUnblocks();
			return CoordinationResult.RETRY;
		}
	}
	
	public CoordinationResult handleRule3(String request, CoordinationDelegate coordinationDelegateFrom, Coord coord, ChoreographyState globalState) {
		CoordinationDelegateManager manager = CoordinationDelegateFactory.getInstance().getCoordinationDelegateManager();
		TimeStampManager timeStampManager = CoordinationDelegateFactory.getInstance().getTimeStampManager();
		manager.updateGlobaState(request, coordinationDelegateFrom, coord, globalState);
		CDQueue cdQueue = manager.getCDQueue(request, coordinationDelegateFrom, coord );
		List<CDQueueElement> blockElements = cdQueue.getBlockElements();
		for (CDQueueElement element : blockElements) {
			int timeStamp = timeStampManager.incrementTimeStamp();
			manager.sendUnBlock(request, coordinationDelegateFrom.getName(), element.getCoordinationDelegateTo().getName(), timeStamp, globalState);
		}
		return CoordinationResult.FORWARD;
	}	

}
