package it.univaq.di.choreos.stockconfirm.fineco.cd;


import it.univaq.di.choreos.coordinationprotocol.algorithm.CoordinationDelegateFacade;
import it.univaq.di.choreos.coordinationprotocol.algorithm.model.ChoreographyState;
import it.univaq.di.choreos.coordinationprotocol.algorithm.model.CoordinationDelegate;
import it.univaq.di.choreos.coordinationprotocol.algorithm.model.CoordinationResult;
import it.univaq.di.choreos.coordinationprotocol.algorithm.model.CoordMM.Coord;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

@WebService( serviceName="StockConfirm", targetNamespace="http://choreos.di.univaq.it", portName="StockConfirmPort" )
public class StockConfirm {

	private static CoordinationDelegate COORDINATION_DELEGATE = new CoordinationDelegate("fineco-cd");
	private static final String REQUEST = "orderconfirm";
	private Coord coord = new Coord();
	private ChoreographyState globalState = ChoreographyState.INITIAL_STATE;
	
	@WebMethod( operationName="orderconfirm" )
	//@Oneway
	public void orderconfirm( @WebParam( name="orderNumber" ) String orderNumber, @WebParam( name="quantity" ) int quantity ) {
		System.out.println("prima di facade");
		CoordinationDelegateFacade facade = new CoordinationDelegateFacade();
		CoordinationResult result = facade.handleRules(REQUEST, COORDINATION_DELEGATE, coord, globalState);
		
		if (result==CoordinationResult.FORWARD) {
			//Forward message
			facade.handleRule3(REQUEST, COORDINATION_DELEGATE, coord, globalState);
		}
		if (result==CoordinationResult.DISCARD) {
			//Discard message
		}
		System.out.println("dopo di facade");
	}
}