package it.univaq.di.choreos.coordinationprotocol.algorithm.model;

import java.util.ArrayList;
import java.util.List;

public class CDQueue {
	
	private List<CDQueueElement> blockElements = new ArrayList<CDQueueElement>();
	private List<CDQueueElement> blockWithAckElements = new ArrayList<CDQueueElement>();
	
	public CDQueue() {
	}
	
	public synchronized void addBlock(CDQueueElement element) {
		blockElements.add(element);
	}

	public synchronized void waitAllAcks() {
		if (!blockElements.isEmpty()) {
			try {
				wait();
				
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
	public synchronized void removeAndNotify(CDQueueElement element) {
		if (blockElements.remove(element)) {
			blockWithAckElements.add(element);	
		}
		
		if (blockElements.isEmpty()) {
			notifyAll();
		}
	}

	public List<CDQueueElement> getBlockElements() {
		return blockWithAckElements;
	}

	public synchronized void waitForAllUnblocks() {
		
	}
	
	
}
