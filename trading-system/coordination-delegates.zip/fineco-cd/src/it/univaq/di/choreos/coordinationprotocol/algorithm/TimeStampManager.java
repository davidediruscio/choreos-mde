package it.univaq.di.choreos.coordinationprotocol.algorithm;

public interface TimeStampManager {
	public int incrementTimeStamp();
	public int getTimeStamp();
	public void resetTimeStamp();
	
}
