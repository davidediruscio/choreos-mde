package it.univaq.di.choreos.coordinationprotocol.algorithm;

import it.univaq.di.choreos.coordinationprotocol.algorithm.impl.CoordinationManagerImpl;
import it.univaq.di.choreos.coordinationprotocol.algorithm.impl.TimeStampManagerImpl;

public class CoordinationDelegateFactory {
	private static final CoordinationDelegateFactory instance = new CoordinationDelegateFactory();
	
	private CoordinationDelegateManager coordinationDelegateManager;
	private TimeStampManager timeStampManager;
	
	private CoordinationDelegateFactory() {
		this.coordinationDelegateManager = new CoordinationManagerImpl();
		this.timeStampManager = new TimeStampManagerImpl();
		
	}
	
	public static final CoordinationDelegateFactory getInstance() {
		return instance;
	}
	
	public CoordinationDelegateManager getCoordinationDelegateManager() {
		return coordinationDelegateManager;
	}
	
	public TimeStampManager getTimeStampManager() {
		return timeStampManager;
	}
	

}
