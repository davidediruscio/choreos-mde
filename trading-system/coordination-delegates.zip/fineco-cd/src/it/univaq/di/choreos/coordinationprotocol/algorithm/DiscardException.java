package it.univaq.di.choreos.coordinationprotocol.algorithm;

import javax.xml.ws.WebFault;

@WebFault
public class DiscardException extends Exception {

	public DiscardException() {
		super();
	}

	public DiscardException(String message, Throwable cause) {
		super(message, cause);
	}

	public DiscardException(String message) {
		super(message);
	}

	public DiscardException(Throwable cause) {
		super(cause);
	}
	
	

}
