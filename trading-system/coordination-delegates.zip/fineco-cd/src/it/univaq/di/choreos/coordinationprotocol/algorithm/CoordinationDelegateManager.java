package it.univaq.di.choreos.coordinationprotocol.algorithm;

import it.univaq.di.choreos.coordinationprotocol.algorithm.model.ChoreographyState;
import it.univaq.di.choreos.coordinationprotocol.algorithm.model.CoordinationResult;
import it.univaq.di.choreos.coordinationprotocol.algorithm.model.CDQueue;
import it.univaq.di.choreos.coordinationprotocol.algorithm.model.CoordinationDelegate;
import it.univaq.di.choreos.coordinationprotocol.algorithm.model.CoordMM.Coord;

import java.util.List;

public interface CoordinationDelegateManager {
	

	public CoordinationResult isRequestAllowedFromS(String request, CoordinationDelegate coordinationDelegateFrom, Coord coord);
	public List<CoordinationDelegate> getAllCoordinationDelegate(String request, CoordinationDelegate coordinationDelegateFrom, Coord coord);
	public CDQueue getCDQueue(String request, CoordinationDelegate coordinationDelegateFrom, Coord coord);
	boolean isPrivilegeGranted(String request, CoordinationDelegate coordinationDelegateFrom, Coord coord, ChoreographyState globalState);
	public void updateGlobaState(String request, CoordinationDelegate coordinationDelegateFrom, Coord coord, ChoreographyState globalState);

	public void sendBlock(String request, String coordinationDelegateFrom, String coordinationDelegateTo, int timeStamp, ChoreographyState globalState);
	public void ack(String request, CoordinationDelegate coordinationDelegateFrom, int timeStamp, ChoreographyState globalState);
	public void sendUnBlock(String request, String coordinationDelegateFrom, String coordinationDelegateTo, int timeStamp, ChoreographyState globalState);
	
}
