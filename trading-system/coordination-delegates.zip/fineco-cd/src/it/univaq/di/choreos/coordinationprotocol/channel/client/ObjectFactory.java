
package it.univaq.di.choreos.coordinationprotocol.channel.client;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the it.univaq.di.choreos.coordinationprotocol.channel.client package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _Block_QNAME = new QName("http://choreos.di.univaq.it", "block");
    private final static QName _Ack_QNAME = new QName("http://choreos.di.univaq.it", "ack");
    private final static QName _Unblock_QNAME = new QName("http://choreos.di.univaq.it", "unblock");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: it.univaq.di.choreos.coordinationprotocol.channel.client
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link Unblock }
     * 
     */
    public Unblock createUnblock() {
        return new Unblock();
    }

    /**
     * Create an instance of {@link Block }
     * 
     */
    public Block createBlock() {
        return new Block();
    }

    /**
     * Create an instance of {@link Ack }
     * 
     */
    public Ack createAck() {
        return new Ack();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Block }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://choreos.di.univaq.it", name = "block")
    public JAXBElement<Block> createBlock(Block value) {
        return new JAXBElement<Block>(_Block_QNAME, Block.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Ack }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://choreos.di.univaq.it", name = "ack")
    public JAXBElement<Ack> createAck(Ack value) {
        return new JAXBElement<Ack>(_Ack_QNAME, Ack.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Unblock }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://choreos.di.univaq.it", name = "unblock")
    public JAXBElement<Unblock> createUnblock(Unblock value) {
        return new JAXBElement<Unblock>(_Unblock_QNAME, Unblock.class, null, value);
    }

}
