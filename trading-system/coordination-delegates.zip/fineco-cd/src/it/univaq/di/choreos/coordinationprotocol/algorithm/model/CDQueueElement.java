package it.univaq.di.choreos.coordinationprotocol.algorithm.model;

public class CDQueueElement {
	
	private int timeStamp;
	private CoordinationDelegate coordinationDelegateTo;

	public CDQueueElement() {
		super();
	}
	
	public CDQueueElement(int timeStamp, CoordinationDelegate coordinationDelegateTo) {
		super();
		this.timeStamp = timeStamp;
		this.coordinationDelegateTo = coordinationDelegateTo;
	}

	public int getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(int timeStamp) {
		this.timeStamp = timeStamp;
	}

	public CoordinationDelegate getCoordinationDelegateTo() {
		return coordinationDelegateTo;
	}

	public void setCoordinationDelegateTo(CoordinationDelegate coordinationDelegateTo) {
		this.coordinationDelegateTo = coordinationDelegateTo;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((coordinationDelegateTo == null) ? 0 : coordinationDelegateTo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CDQueueElement other = (CDQueueElement) obj;
		if (coordinationDelegateTo == null) {
			if (other.coordinationDelegateTo != null)
				return false;
		} else if (!coordinationDelegateTo.equals(other.coordinationDelegateTo))
			return false;
		return true;
	}
	
	

}
