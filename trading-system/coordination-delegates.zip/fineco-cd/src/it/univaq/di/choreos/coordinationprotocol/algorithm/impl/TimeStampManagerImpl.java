package it.univaq.di.choreos.coordinationprotocol.algorithm.impl;

import it.univaq.di.choreos.coordinationprotocol.algorithm.TimeStampManager;

public class TimeStampManagerImpl implements TimeStampManager {
	private int counter = 0;
	
	@Override
	public synchronized int incrementTimeStamp() {
		return counter++;
	}

	@Override
	public synchronized int getTimeStamp() {
		return counter;
	}

	@Override
	public synchronized void resetTimeStamp() {
		counter = 0;
		
	}

}
