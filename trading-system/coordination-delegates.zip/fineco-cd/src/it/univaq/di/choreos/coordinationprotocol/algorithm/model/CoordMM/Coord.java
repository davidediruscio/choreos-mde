package it.univaq.di.choreos.coordinationprotocol.algorithm.model.CoordMM;

public class Coord  {
} 
