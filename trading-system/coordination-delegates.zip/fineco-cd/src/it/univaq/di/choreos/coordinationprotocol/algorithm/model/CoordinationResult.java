package it.univaq.di.choreos.coordinationprotocol.algorithm.model;

public enum CoordinationResult {

	ALLOWED, DISCARD, FORWARD, RETRY;
}
