package it.univaq.di.choreos.coordinationprotocol.algorithm.model;

public class ChoreographyState {
	
	public static final ChoreographyState INITIAL_STATE = new ChoreographyState(0);
	private int state;
	
	public ChoreographyState(int state) {
		super();
		this.state = state;
	}

	public int getState() {
		return state;
	}

	public void setState(int state) {
		this.state = state;
	}
	
	
	

}
