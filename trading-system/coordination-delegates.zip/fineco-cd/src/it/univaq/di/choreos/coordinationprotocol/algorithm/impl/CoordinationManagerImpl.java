package it.univaq.di.choreos.coordinationprotocol.algorithm.impl;

import it.univaq.di.choreos.coordinationprotocol.algorithm.CoordinationDelegateManager;
import it.univaq.di.choreos.coordinationprotocol.algorithm.model.ChoreographyState;
import it.univaq.di.choreos.coordinationprotocol.algorithm.model.CoordinationResult;
import it.univaq.di.choreos.coordinationprotocol.algorithm.model.CDQueue;
import it.univaq.di.choreos.coordinationprotocol.algorithm.model.CDQueueElement;
import it.univaq.di.choreos.coordinationprotocol.algorithm.model.CoordinationDelegate;
import it.univaq.di.choreos.coordinationprotocol.algorithm.model.CoordMM.Coord;
import it.univaq.di.choreos.coordinationprotocol.channel.Utility;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CoordinationManagerImpl implements CoordinationDelegateManager {
	private Map<String, CDQueue> requests = Collections.synchronizedMap(new HashMap<String, CDQueue>());
	
	
	@Override
	public List<CoordinationDelegate> getAllCoordinationDelegate(String request, CoordinationDelegate coordinationDelegateFrom, Coord coord) {
		List<CoordinationDelegate> coordinationDelegates = new ArrayList<CoordinationDelegate>();
		CoordinationDelegate coordinationDelegate = new CoordinationDelegate("ubs-cd");
		coordinationDelegates.add(coordinationDelegate);
		CoordinationDelegate coordinationDelegate1 = new CoordinationDelegate("iwbank-cd");
		coordinationDelegates.add(coordinationDelegate1);
		return coordinationDelegates;
	}

	@Override
	public CoordinationResult isRequestAllowedFromS(String request, CoordinationDelegate coordinationDelegateFrom, Coord coord) {
		return CoordinationResult.ALLOWED;
	}

	@Override
	public CDQueue getCDQueue(String request, CoordinationDelegate coordinationDelegateFrom, Coord coord) {
		CDQueue result = requests.get(request);
		if (result==null) {
			result = new CDQueue();
			requests.put(request, result);
		}
		
		return result;
	}

	@Override
	public boolean isPrivilegeGranted(String request, CoordinationDelegate coordinationDelegateFrom, Coord coord, ChoreographyState globalState) {
		return true;
	}

	@Override
	public void updateGlobaState(String request, CoordinationDelegate coordinationDelegateFrom, Coord coord, ChoreographyState globalState) {
		globalState.setState(globalState.getState()+1);
		
	}
	
	@Override
	public void sendBlock(String request, String coordinationDelegateFrom, String coordinationDelegateTo, int timeStamp, ChoreographyState globalState) {
		Utility.sendBlock(request, coordinationDelegateFrom, coordinationDelegateTo, timeStamp);
		
	}

	@Override
	public void sendUnBlock(String request, String coordinationDelegateFrom, String coordinationDelegateTo, int timeStamp, ChoreographyState globalState) {
		Utility.sendUnBlock(request, coordinationDelegateFrom, coordinationDelegateTo, timeStamp);
		
	}
	
	@Override
	public void ack(String request, CoordinationDelegate coordinationDelegateFrom, int timeStamp, ChoreographyState globalState) {
		CDQueue cdQueue = getCDQueue(request, coordinationDelegateFrom, null);
		if (cdQueue!=null) {
			CDQueueElement cdQueueElement = new CDQueueElement(timeStamp, coordinationDelegateFrom);
			cdQueue.removeAndNotify(cdQueueElement);
		}
	}


}
