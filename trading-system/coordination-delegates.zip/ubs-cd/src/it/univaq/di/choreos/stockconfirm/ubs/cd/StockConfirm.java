package it.univaq.di.choreos.stockconfirm.ubs.cd;


import javax.jws.Oneway;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

@WebService( serviceName="StockConfirm", targetNamespace="http://choreos.di.univaq.it", portName="StockConfirmPort" )
public class StockConfirm {

	@WebMethod( operationName="orderconfirm" )
	//@Oneway
	public void orderconfirm( @WebParam( name="orderNumber" ) String orderNumber, @WebParam( name="quantity" ) int quantity ) {
		System.out.println("prima del lock");
		/*
		synchronized (this) {
			try {
				wait(40000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		*/
		System.out.println("dopo lock");
	}
}