package it.univaq.di.choreos.coordinationprotocol.channel;

import javax.jws.Oneway;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

@WebService( serviceName="WSCoordinationChannel", targetNamespace="http://choreos.di.univaq.it", portName="WSCoordinationChannelPort" )
public class WSCoordinationChannel {

	@WebMethod( operationName="block" )
	@Oneway
	public void block( @WebParam( name="request" ) String request, @WebParam( name="coordinationdelegatefrom" ) String coordinationdelegatefrom, @WebParam( name="timestamp" ) int timestamp ) {
		System.out.println("sono dentro il ubs-cd prima di wait di 4 secondi");
		
		synchronized (this) {
			try {
				wait(4000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		System.out.println("prima dell'ack di ubs-cd");
		Utility.sendAck(request, "ubs-cd", coordinationdelegatefrom, timestamp);
		System.out.println("dopo dell'ack di ubs-cd");
	}

	@WebMethod( operationName="ack" )
	@Oneway
	public void ack( @WebParam( name="request" ) String request, @WebParam( name="coordinationdelegatefrom" ) String coordinationdelegatefrom, @WebParam( name="timestamp" ) int timestamp ) {
	}

	@WebMethod( operationName="unblock" )
	@Oneway
	public void unblock( @WebParam( name="request" ) String request, @WebParam( name="coordinationdelegatefrom" ) String coordinationdelegatefrom, @WebParam( name="timestamp" ) int timestamp ) {
	}
}
