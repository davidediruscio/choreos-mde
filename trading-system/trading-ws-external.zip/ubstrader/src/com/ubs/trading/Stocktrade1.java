package com.ubs.trading;

import it.univaq.di.choreos.stockconfirm.client.StockConfirm;
import it.univaq.di.choreos.stockconfirm.client.StockConfirm_Service;

import java.net.MalformedURLException;
import java.net.URL;

import javax.jws.Oneway;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.xml.namespace.QName;

@WebService( serviceName="Stocktrade1", targetNamespace="http://trading.ubs.com", portName="Stocktrade1Port" )
public class Stocktrade1 {
	
	private final static URL STOCKCONFIRM_WSDL_LOCATION;

    static {
        URL url = null;
        try {
            URL baseUrl;
            baseUrl = it.univaq.di.choreos.stockconfirm.client.StockConfirm_Service.class.getResource(".");
            url = new URL(baseUrl, "http://localhost:11080/ubs-cd/stockconfirmubs?wsdl");
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        STOCKCONFIRM_WSDL_LOCATION = url;
    }
    
	@WebMethod( operationName="buy1" )
	@Oneway
	public void buy1( @WebParam( name="orderNumber" ) String orderNumber, @WebParam( name="stockSymbol" ) String stockSymbol, @WebParam( name="quantity" ) int quantity ) {
		System.out.println("UBS:StockTrade->buy1");

		StockConfirm_Service stockConfirmService = new StockConfirm_Service(STOCKCONFIRM_WSDL_LOCATION, new QName("http://choreos.di.univaq.it", "StockConfirm"));
		StockConfirm stockConfirmPort = stockConfirmService.getStockConfirmPort();
		stockConfirmPort.orderconfirm(orderNumber, quantity);
		System.out.println("UBS:StockTrade->trade->dopo orderconfirm");
	}
	
}