package it.iwbank.trading;

import java.net.MalformedURLException;
import java.net.URL;

import it.univaq.di.choreos.stockconfirm.client.StockConfirm;
import it.univaq.di.choreos.stockconfirm.client.StockConfirm_Service;

import javax.jws.Oneway;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.xml.namespace.QName;

@WebService( serviceName="Stocktrade3", targetNamespace="http://trading.iwbank.it", portName="Stocktrade3Port" )
public class Stocktrade3 {
	private final static URL STOCKCONFIRM_WSDL_LOCATION;

    static {
        URL url = null;
        try {
            URL baseUrl;
            baseUrl = it.univaq.di.choreos.stockconfirm.client.StockConfirm_Service.class.getResource(".");
            url = new URL(baseUrl, "http://localhost:12080/iwbank-cd/stockconfirmiwbank?wsdl");
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        STOCKCONFIRM_WSDL_LOCATION = url;
    }
    
    @WebMethod( operationName="buy3" )
	@Oneway
	public void buy3( @WebParam( name="orderNumber" ) String orderNumber, @WebParam( name="stockSymbol" ) String stockSymbol, @WebParam( name="quantity" ) int quantity ) {		System.out.println("IWBank:AcquistoAzioni->negozia");
		StockConfirm_Service stockConfirmService = new StockConfirm_Service(STOCKCONFIRM_WSDL_LOCATION, new QName("http://choreos.di.univaq.it", "StockConfirm"));
		StockConfirm stockConfirmPort = stockConfirmService.getStockConfirmPort();
		stockConfirmPort.orderconfirm(orderNumber, quantity);
		System.out.println("IWBank:AcquistoAzioni->negozia-> dopo orderconfirm");
	}
}