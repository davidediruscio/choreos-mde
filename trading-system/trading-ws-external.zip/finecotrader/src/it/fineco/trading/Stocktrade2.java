package it.fineco.trading;

import java.net.MalformedURLException;
import java.net.URL;

import it.univaq.di.choreos.stockconfirm.client.StockConfirm;
import it.univaq.di.choreos.stockconfirm.client.StockConfirm_Service;

import javax.jws.Oneway;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.xml.namespace.QName;

@WebService( serviceName="Stocktrade2", targetNamespace="http://trading.fineco.it", portName="Stocktrade2Port" )
public class Stocktrade2 {
	private final static URL STOCKCONFIRM_WSDL_LOCATION;

    static {
        URL url = null;
        try {
            URL baseUrl;
            baseUrl = it.univaq.di.choreos.stockconfirm.client.StockConfirm_Service.class.getResource(".");
            url = new URL(baseUrl, "http://localhost:10080/fineco-cd/stockconfirmfineco?wsdl");
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        STOCKCONFIRM_WSDL_LOCATION = url;
    }
	
    @WebMethod( operationName="buy2" )
	@Oneway
	public void buy2( @WebParam( name="orderNumber" ) String orderNumber, @WebParam( name="stockSymbol" ) String stockSymbol, @WebParam( name="quantity" ) int quantity ) {
		// Ordina e poi invoca il metodo di StockBuy orderconfirm
		System.out.println("Fineco:TitoliAzionari->compra");

		StockConfirm_Service stockConfirmService = new StockConfirm_Service(STOCKCONFIRM_WSDL_LOCATION, new QName("http://choreos.di.univaq.it", "StockConfirm"));
		StockConfirm stockConfirmPort = stockConfirmService.getStockConfirmPort();
		stockConfirmPort.orderconfirm(orderNumber, quantity);
		System.out.println("Fineco:TitoliAzionari->compra->dopo orderconfirm");

	}
}
